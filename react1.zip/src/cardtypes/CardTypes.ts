export type CardTypes={
    content:string,
    image:string,
    price:{amount: number, currency: string},
}